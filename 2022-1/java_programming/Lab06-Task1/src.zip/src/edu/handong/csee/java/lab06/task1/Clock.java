package edu.handong.csee.java.lab06.task1;

public class Clock {

    private String currentTime;
    private String color;
    private String type;

    public void setCurrentTime(String inputTime){

        currentTime = inputTime;

    }

    public String getCurrentTime(){

        return currentTime;
        
    }

    public void setColor(String inputColor){

        color = inputColor;
        
    }

    public String getColor(){

        return color;
        
    }

    public void setType(String inputType){

        type = inputType;
        
    }

    public String getType(){

        return type;
        

    }

    
}

