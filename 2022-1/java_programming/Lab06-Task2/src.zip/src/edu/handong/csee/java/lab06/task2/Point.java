package edu.handong.csee.java.lab06.task2;


public class Point {
    public int x = 0;
    public int y = 0;
    // a constructor!
    public Point(int a, int b) {
    	x = a;
    	y = b;
    }
}
